from asn1crypto import cms, core, x509

__all__ = ['as_set_of', 'register_cms_attribute', 'register_x509_extension']


def as_set_of(asn1_type: type):
    return type(
        'SetOf' + asn1_type.__name__, (core.SetOf,), {'_child_spec': asn1_type}
    )


def register_cms_attribute(
    dotted_oid: str, readable_name: str, asn1_type: type
):
    cms.CMSAttributeType._map[dotted_oid] = readable_name
    cms.CMSAttribute._oid_specs[readable_name] = as_set_of(asn1_type)


def register_x509_extension(
    dotted_oid: str,
    readable_name: str,
    asn1_type: type,
):
    x509.ExtensionId._map[dotted_oid] = readable_name
    x509.Extension._oid_specs[readable_name] = asn1_type
